package com.lin.survey.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.wenjuan.R;
import com.lin.survey.utils.IdCardUtil;

/**
 * Created by Admin on 2018/6/9.
 */

public class BasciInfoPageFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.basci_info_page,
                container, false);
        final EditText ID = (EditText)rootView.findViewById(R.id.ID);
        ID.setOnFocusChangeListener(new android.view.View.
                OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    // 此处为得到焦点时的处理内容
                } else {
                    String ID_text = ID.getText().toString().trim();
                    IdCardUtil idCardUtil = new IdCardUtil(ID_text);
                    if(ID_text != null && ID_text != ""){
                        if(0 != idCardUtil.isCorrect()){}
                        Toast.makeText(getActivity(), "你输入的身份证号码有误", Toast.LENGTH_SHORT).show();
                    }
                }
            }
            });
        return rootView;
    }
}
