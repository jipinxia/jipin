package com.lin.survey.adapter;


import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.lin.survey.activity.MainActivity;
import com.lin.survey.fragment.BasciInfoPageFragment;
import com.lin.survey.fragment.CoverPageFragment;
import com.lin.survey.fragment.QuestionEightFragment;
import com.lin.survey.fragment.QuestionEighteenFragment;
import com.lin.survey.fragment.QuestionElevenFragment;
import com.lin.survey.fragment.QuestionFifteenFragment;
import com.lin.survey.fragment.QuestionFiftyFragment;
import com.lin.survey.fragment.QuestionFiftyOneFragment;
import com.lin.survey.fragment.QuestionFiftyTwoFragment;
import com.lin.survey.fragment.QuestionFiveFragment;
import com.lin.survey.fragment.QuestionFortyEightFragment;
import com.lin.survey.fragment.QuestionFortyFiveFragment;
import com.lin.survey.fragment.QuestionFortyFourFragment;
import com.lin.survey.fragment.QuestionFortyNineFragment;
import com.lin.survey.fragment.QuestionFortyOneFragment;
import com.lin.survey.fragment.QuestionFortySevenFragment;
import com.lin.survey.fragment.QuestionFortySixFragment;
import com.lin.survey.fragment.QuestionFortyThreeFragment;
import com.lin.survey.fragment.QuestionFortyTwoFragment;
import com.lin.survey.fragment.QuestionFourFragment;
import com.lin.survey.fragment.QuestionFourteenFragment;
import com.lin.survey.fragment.QuestionNineFragment;
import com.lin.survey.fragment.QuestionNineteenFragment;
import com.lin.survey.fragment.QuestionOneFragment;
import com.lin.survey.fragment.QuestionItemFragment;
import com.lin.survey.fragment.QuestionSevenFragment;
import com.lin.survey.fragment.QuestionSeventeenFragment;
import com.lin.survey.fragment.QuestionSixFragment;
import com.lin.survey.fragment.QuestionSixteenFragment;
import com.lin.survey.fragment.QuestionTenFragment;
import com.lin.survey.fragment.QuestionThirteenFragment;
import com.lin.survey.fragment.QuestionThirtyEightFragment;
import com.lin.survey.fragment.QuestionThirtyFiveFragment;
import com.lin.survey.fragment.QuestionThirtyFourFragment;
import com.lin.survey.fragment.QuestionThirtyOneFragment;
import com.lin.survey.fragment.QuestionThirtySixFragment;
import com.lin.survey.fragment.QuestionThirtyThreeFragment;
import com.lin.survey.fragment.QuestionThirtyTwoFragment;
import com.lin.survey.fragment.QuestionTwelveFragment;
import com.lin.survey.fragment.QuestionTwentyEightFragment;
import com.lin.survey.fragment.QuestionTwentyFiveFragment;
import com.lin.survey.fragment.QuestionTwentyFourFragment;
import com.lin.survey.fragment.QuestionTwentyFragment;
import com.lin.survey.fragment.QuestionTwentyNineFragment;
import com.lin.survey.fragment.QuestionTwentyOneFragment;
import com.lin.survey.fragment.QuestionTwentySevenFragment;
import com.lin.survey.fragment.QuestionTwentySixFragment;
import com.lin.survey.fragment.QuestionTwentyThreeFragment;
import com.lin.survey.fragment.QuestionTwentyTwoFragment;
import com.lin.survey.fragment.ScantronItemFragment;
import com.lin.survey.fragment.QuestionThreeFragment;
import com.lin.survey.fragment.QuestionTwoFragment;

/**
 * @Description: ViewPager的数据适配器
 * @author hzc
 */
public class ItemAdapter extends FragmentStatePagerAdapter {
	Context context;
	public ItemAdapter(FragmentManager fm) {
		super(fm);
	}
	@Override
	public Fragment getItem(int arg0) {
		if(arg0 == MainActivity.questionlist.size()){
			return new ScantronItemFragment();
		}else if (arg0 ==0){
			return new QuestionFortySevenFragment();
		}else if (arg0 ==1){
			return new QuestionFiftyTwoFragment();
		}else if (arg0 ==2){
			return new QuestionFortyNineFragment();
		}else if (arg0 ==3){
			return new QuestionFiftyOneFragment();
		}
		return new QuestionItemFragment(arg0);
	}
 

	@Override
	public int getCount() {
		 
		return MainActivity.questionlist.size()+1;
	}
  


}
