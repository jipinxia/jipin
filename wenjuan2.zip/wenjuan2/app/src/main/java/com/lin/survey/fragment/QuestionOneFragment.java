package com.lin.survey.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.example.admin.wenjuan.R;
import com.google.gson.Gson;
import com.lin.survey.adapter.MultilevelAdapter;
import com.lin.survey.bean.FoodModel;
import com.lin.survey.utils.MyDialog;
import com.lin.survey.utils.UtilTools;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Admin on 2018/6/9.
 */

public class QuestionOneFragment extends Fragment {
    private Button occupation;
    private String multilevelData;
    private View rootView;
    //多级
    private List<FoodModel.Range> rangeList;//一级
    private List<FoodModel.Range.Sub> rangeList_selected;//二级多选被选中的集合
    //private MyDialog multilevelDialog;//多级多选Dialog
    private MyDialog multi_choiceDialog;//多级单选Dialog
    //单级
    private List<FoodModel.Range.Sub> singleLevelList;//二级
    private List<String> singleLevelList_selected;//单级多选 选中的集合
   // private MyDialog single_radioDialog;//单级单选Dialog
  //  private MyDialog single_stage_selectionDialog;//单级多选Dialog

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.question_one,container, false);
        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        rangeList = new ArrayList<>();
        rangeList_selected = new ArrayList<>();
        //单级
        singleLevelList = new ArrayList<>();
        singleLevelList_selected = new ArrayList<>();
        getData();
        setData();
        occupation = (Button) getView().findViewById(R.id.occupation);
        Log.e("occupation",""+R.id.occupation);
        occupation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showMulti_choice(occupation,rangeList);
            }
        });
    }

    //获取本地数据
    public void getData() {
        try {
            InputStreamReader inputReader = new InputStreamReader(getActivity().getAssets().open("occupation.json"));
            BufferedReader bufReader = new BufferedReader(inputReader);
            String line = "";
            while ((line = bufReader.readLine()) != null) {
                multilevelData += line;
            }
            multilevelData = multilevelData.trim().replace(" ", "").replace("null", "");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setData() {
        Log.e("multilevelData", multilevelData);
        Gson gson = new Gson();
        FoodModel model = gson.fromJson(multilevelData, FoodModel.class);
        rangeList = model.getRange();
        singleLevelList = rangeList.get(0).getSub();
    }

    /**
     * @param choice 多级单选
     */
    public void showMulti_choice(final Button choice,final List<FoodModel.Range> rangeLists) {
        View rangeView = LayoutInflater.from(getActivity()).inflate(R.layout.multi_select, null);
        Button cancel, sure;
        cancel = (Button) rangeView.findViewById(R.id.cancel);
        sure = (Button) rangeView.findViewById(R.id.sure);
        final TextView choice_areas = (TextView) rangeView.findViewById(R.id.choice_areas);
        ExpandableListView exListView = (ExpandableListView) rangeView.findViewById(R.id.exListView);
        exListView.setGroupIndicator(null);//默认图标不显示
        Log.e("method",rangeLists.toString());
        final MultilevelAdapter adapter = new MultilevelAdapter(getActivity(), rangeLists);
        exListView.setAdapter(adapter);
        // 设置一级item点击的监听器
        exListView.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {
            @Override
            public boolean onGroupClick(ExpandableListView parent, View v,
                                        int groupPosition, long id) {
                if (rangeLists.get(groupPosition).isParent_select() == false) {
                    rangeLists.get(groupPosition).setParent_select(true);
                } else {
                    rangeLists.get(groupPosition).setParent_select(false);
                }
                return false;
            }
        });
        // 设置二级item点击的监听器
        exListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v,
                                        int groupPosition, int childPosition, long id) {
                MultilevelAdapter.ChilViewHolder viewHolder = (MultilevelAdapter.ChilViewHolder) v.getTag();
                viewHolder.checkBox.toggle();
                adapter.clear();
                MultilevelAdapter.childIsSelector.get(groupPosition).put(childPosition, viewHolder.checkBox.isChecked());
                if (viewHolder.checkBox.isChecked()) {
                    choice_areas.setText(rangeList.get(groupPosition).getSub().get(childPosition).getName());
                } else {
                    choice_areas.setText("");
                }
                return false;
            }
        });
        int width = UtilTools.getScreenWidth(getActivity()) * 6 / 7;
        int height = UtilTools.getScreenHeight(getActivity()) - UtilTools.getStatusBarHeight(getActivity());//屏幕高度-状态栏和标题栏高度
        if (multi_choiceDialog == null) {
            multi_choiceDialog = new MyDialog(this.getContext(), R.style.MyDialog, rangeView);
            multi_choiceDialog.show();
            WindowManager.LayoutParams lp = multi_choiceDialog.getWindow().getAttributes();
            lp.width = width;
            lp.height = height;
            lp.gravity = Gravity.RIGHT | Gravity.BOTTOM;
            multi_choiceDialog.getWindow().setAttributes(lp);
        } else {
            adapter.notifyDataSetChanged();
            multi_choiceDialog.show();
        }
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                multi_choiceDialog.hide();
            }
        });
        sure.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                multi_choiceDialog.hide();
                String result = choice_areas.getText().toString();
                if (result.equals("")) {
                    choice.setText("请点击选择职业");
                } else {
                    choice.setText(result);
                }

            }
        });
    }


}
